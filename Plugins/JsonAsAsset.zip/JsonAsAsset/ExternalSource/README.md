# JsonAsAsset's API
API to allow asset downloading at runtime, for JsonAsAsset.

