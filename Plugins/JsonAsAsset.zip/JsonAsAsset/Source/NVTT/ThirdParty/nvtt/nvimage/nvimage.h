// This code is in the public domain -- castanyo@yahoo.es

#ifndef NV_IMAGE_H
#define NV_IMAGE_H

#include <nvcore/nvcore.h>

// Function linkage
#define NVIMAGE_API
#define NVIMAGE_CLASS

#endif // NV_IMAGE_H
